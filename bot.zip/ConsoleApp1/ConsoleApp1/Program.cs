﻿using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;

var botClient = new TelegramBotClient("6541976420:AAFO0WNeYuiyjioVXjAIurmdDCQvHj3CXNA");

using CancellationTokenSource cts = new();

ReceiverOptions receiverOptions = new()
{
    AllowedUpdates = Array.Empty<UpdateType>() // receive all update types except ChatMember related updates
};

botClient.StartReceiving(
    updateHandler: HandleUpdateAsync,
    pollingErrorHandler: HandlePollingErrorAsync,
    receiverOptions: receiverOptions,
    cancellationToken: cts.Token
);

var me = await botClient.GetMeAsync();

Console.WriteLine($"Start listening for @{me.Username}");
Console.ReadLine();

// Send cancellation request to stop bot
cts.Cancel();

async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
{
    // Only process Message updates: https://core.telegram.org/bots/api#message
    if (update.Message is not { } message)
        return;
    // Only process text messages
    if (message.Text is not { } messageText)
        return;

    var chatId = message.Chat.Id;
    var username = update.Message.From.Username;

    Console.WriteLine($"Received a '{messageText}' message in chat {chatId}.");

    if (messageText == "Привет")
    {
        await botClient.SendTextMessageAsync(
            chatId: chatId,
            text: "Здравствуй, " + username,
            cancellationToken: cancellationToken);
    }
    if (messageText == "Пикча")
    {
        Message message1 = await botClient.SendPhotoAsync(
            chatId: chatId,
            photo: InputFile.FromUri("https://sun9-37.userapi.com/impg/rpffeG6W7N_8r-Vzq6nF3VfAGUkkhS1SAzDjTg/VVtjawWaa1s.jpg?size=640x642&quality=96&sign=91878d8405ca1d372454b9c783690ba2&type=album"),
            caption: "<b>рандом пикча из сохр</b>",
            parseMode: ParseMode.Html,
            cancellationToken: cancellationToken);
    }
    if (messageText == "Видео")
    {
        Message message2 = await botClient.SendVideoAsync(
            chatId: chatId,
            video: InputFile.FromUri("https://github.com/quapse/tbot/blob/main/Download.mp4"),
            supportsStreaming: true,
            cancellationToken: cancellationToken);

    }
}

Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
{
    var ErrorMessage = exception switch
    {
        ApiRequestException apiRequestException
            => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
        _ => exception.ToString()
    };

    Console.WriteLine(ErrorMessage);
    return Task.CompletedTask;
}